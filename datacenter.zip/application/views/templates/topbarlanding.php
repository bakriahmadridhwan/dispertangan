<body class="hold-transition layout-top-nav">
    <div class="wrapper">

        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand-md navbar-light navbar-green m-0 p-0">
            <div class="container">
                <!-- Left navbar links -->

                <nav class="navbar bg-gradient-success m-0 pr-0 pl-2 py-0">
                    <a class="navbar-brand" href="#">
                        <img src="<?php echo base_url() ?>assets/dist/img/logo_home.png" height="30" class="d-inline-block align-top" alt="">
                    </a>
                </nav>
                <nav class="navbar m-0 p-0">
                    <a class="btn btn-primary" href="<?= base_url('auth') ?>" role="button">Login</a>
                </nav>
            </div>
        </nav>
        <!-- /.navbar -->